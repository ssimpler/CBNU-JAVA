
public class ElseIfTest {

	public static void main(String[] args) {
		int jumsu = 120;
		if(jumsu>=80 && jumsu<= 100)
		{
			System.out.println("A�Դϴ�");
		}
		else if(jumsu >= 60 && jumsu< 80)
		{
			System.out.println("B�Դϴ�");
		}
		else if(jumsu >= 0 && jumsu < 60)
		{
			System.out.println("F�Դϴ�");
		}
		else
		{
			System.out.println("�߸��� �����Դϴ�");
		}
		// TODO Auto-generated method stub

	}

}

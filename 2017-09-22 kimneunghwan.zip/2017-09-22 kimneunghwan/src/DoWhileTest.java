
public class DoWhileTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a =0;
		do
		{
			a=a+10;
			System.out.println("a=" + a);
		}
		while(a<100);
	}

}

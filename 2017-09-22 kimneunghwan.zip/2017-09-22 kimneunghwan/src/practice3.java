
public class practice3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		while(i<5)
		{
			for(int j=0; j<4-i;j++)
			{
				System.out.print(" ");
			}
			for(int j=0; j<1+i; j++)
			{
				System.out.print("*");
			}
			for(int j=0; j<0+i;j++)
			{
				System.out.print("*");
			}
			for(int j=0; j<4-i;j++)
			{
				System.out.print(" ");
			}
			i++;
			System.out.println();
		}
	}
}

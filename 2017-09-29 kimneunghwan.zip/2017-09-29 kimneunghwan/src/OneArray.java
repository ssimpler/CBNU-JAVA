
public class OneArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] ar = {10,20,30};
		for(int i=0; i<ar.length; i++){
			System.out.println("ar[" + i + "]=" + ar[i]);
		}

	}

}
